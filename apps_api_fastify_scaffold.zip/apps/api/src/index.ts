import { buildServer } from "./server.js";

const app = await buildServer();

const port = app.config.PORT;
const host = app.config.HOST;

try {
  await app.listen({ port, host });
  app.log.info({ port, host }, "api up");
} catch (err) {
  app.log.error(err, "failed to start server");
  process.exit(1);
}
