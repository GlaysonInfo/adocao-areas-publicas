import fastify, { type FastifyInstance } from "fastify";
import cors from "@fastify/cors";
import swagger from "@fastify/swagger";
import swaggerUi from "@fastify/swagger-ui";
import { envPlugin } from "./plugins/env.js";
import { routesPlugin } from "./routes/index.js";
import { errorHandlerPlugin } from "./plugins/error-handler.js";

export async function buildServer(): Promise<FastifyInstance & { config: any }> {
  const app = fastify({
    logger: {
      level: process.env.NODE_ENV === "production" ? "info" : "debug",
      transport:
        process.env.NODE_ENV === "production"
          ? undefined
          : {
              target: "pino-pretty",
              options: { translateTime: "SYS:standard", ignore: "pid,hostname" }
            }
    }
  });

  await app.register(envPlugin);

  await app.register(cors, {
    origin: app.config.CORS_ORIGINS,
    credentials: true
  });

  await app.register(swagger, {
    openapi: {
      info: {
        title: "Adote uma Área Pública — API",
        version: app.config.VERSION
      }
    }
  });

  await app.register(swaggerUi, { routePrefix: "/docs" });

  await app.register(errorHandlerPlugin);
  await app.register(routesPlugin, { prefix: "/" });

  return app as any;
}
