# apps/api — API (Fastify + TypeScript)

## Rodar local
```bash
cd apps/api
npm i
cp .env.example .env
npm run dev
```

## Endpoints
- `GET /health`
- `GET /version`
- Swagger UI: `GET /docs`

## Build & run
```bash
npm run build
npm start
```


## Troubleshooting

- If `tsx` is not recognized, make sure `npm install` finished successfully.
- You can run the dev server with `npm exec tsx watch src/index.ts`.
- If you get an `ETARGET` on `@fastify/swagger-ui`, use a version compatible with Fastify v4 (e.g. `^1.9.2`).
